/*************************************************
 *
 * Author:  
 * Create time: 2013 Aug 30 11:44:32 AM
 * E-Mail: jiaxiaojian@baidu.com
 * version 1.1
 *
*************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <algorithm>
#ifndef  __SKELETON_H_
#define  __SKELETON_H_

#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>


using namespace std;

/***************************************************************************
 * 
 * Copyright (c) 2013 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/
 
 
 
/**
 * @file skeleton.h
 * @author jiaxiaojian(com@baidu.com)
 * @date 2013/08/30 11:44:32
 * @brief 
 *  
 **/




















#endif  //__SKELETON_H_

/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
